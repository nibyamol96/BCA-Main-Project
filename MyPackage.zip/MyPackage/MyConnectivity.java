/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MyPackage;

/**
 *
 * @author A
 */
import java.sql.*;
public class MyConnectivity {
    Connection con;
    Statement stmt;
    ResultSet rs;
    public MyConnectivity()
            {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://127.0.0.1/hypermart","root","");
            stmt=con.createStatement();
        }
        catch(Exception e)
        {
        }
    }
    public String Insert(String qry)
    {
        try
        {
        stmt.executeUpdate(qry);
        return "success";
        }
        catch(Exception e)
        {
           return e.getMessage();
        }
    }
    public String getSingleData(String qry2)
    {
        try
        {
            rs=stmt.executeQuery(qry2);
            if(rs.next())
          {
            return rs.getString(1);
          }
      }
       catch(Exception e)
        {
            return e.getMessage();
        }
        return null;
    }
   
    public ResultSet getTable(String qry2)
    {
        try
        {
            rs=stmt.executeQuery(qry2);
            return rs;
        }
        catch(Exception e)
        {
            return null;
        }
    }
    public String alert(String msg,String path)
    {
    return("<script>alert('"+msg+"');location.href='"+path+"';</script>");
    }
      
}



