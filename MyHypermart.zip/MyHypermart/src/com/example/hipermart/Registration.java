package com.example.hipermart;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;
 
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Registration extends Activity {


	HttpPost httppost;
    StringBuffer buffer;
    HttpResponse response;
    HttpClient httpclient;
    ProgressDialog dialog = null;
    String customer_name,emailid,phone_number,address,password;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_registration);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.registration, menu);
		return true;
	}

	
	@SuppressLint("NewApi")
	public void registernow(View v)
	{
		EditText et=(EditText) findViewById(R.id.name);
		  customer_name=et.getText().toString();
		EditText et1=(EditText) findViewById(R.id.email);
		  emailid=et1.getText().toString();
		EditText et3=(EditText) findViewById(R.id.phoneNumber);
		  phone_number=et3.getText().toString();
		EditText et4=(EditText) findViewById(R.id.address);
		  address=et4.getText().toString();
	    EditText et5=(EditText) findViewById(R.id.password);
	     password=et5.getText().toString();
		//Toast.makeText(getApplicationContext(),customer_name+emailid+phone_number+address,Toast.LENGTH_LONG).show();
		
	     TelephonyManager telephonyManager = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
	     String imei=telephonyManager.getDeviceId();
	     
	     Pattern ps = Pattern.compile("^[a-zA-Z ]+$");
         Matcher ms = ps.matcher(customer_name);
         boolean bs = ms.matches();
         
	     if(bs==false)
	     {
	     Toast.makeText(getApplicationContext(), "Name cannot be Blank", Toast.LENGTH_LONG).show();
	     et.setError("Name cannot be Blank");
	     return;
	     }
	     
	     else if(!android.util.Patterns.EMAIL_ADDRESS.matcher(emailid.toString()).matches())
	     {
	     //Validation for Invalid Email Address
	     Toast.makeText(getApplicationContext(), "Invalid Email", Toast.LENGTH_LONG).show();
	     et1.setError("Invalid Email");
	     return;
	     }
	     else if(!android.util.Patterns.PHONE.matcher(phone_number).matches())
	     {
	    	 
	    	 Toast.makeText(getApplicationContext(), "Invalid Phnumber", Toast.LENGTH_LONG).show();
		     et3.setError("Invalid Phone Number");
	     }
	     else if(password.length()!=6)
	     {
	     Toast.makeText(getApplicationContext(), "password must to be six", Toast.LENGTH_LONG).show();
	     et5.setError("password cannot be Blank");
	     return;
	     }
	     else if(address.length()==0)
	     {
	     Toast.makeText(getApplicationContext(), "address cannot be Blank", Toast.LENGTH_LONG).show();
	     et4.setError("address cannot be Blank");
	     return;
	     }
	     else
	     {
		try
		{ 
			Intent i = new Intent( Intent.ACTION_VIEW, Uri.parse ("http://"+LoginInfo.IPADDRESS+":8080"+"/examples/Q-d-Bay/web/android/registeration.jsp"));
		  // startActivity(i);
			 //Toast.makeText(getBaseContext(), "http://"+LoginInfo.IPADDRESS+":8080"+"/examples/sb/Q-R-D-Bay-Server/web/android/registeration.jsp", Toast.LENGTH_LONG).show();
			httpclient=new DefaultHttpClient();
			HttpPost httppost= new HttpPost("http://"+LoginInfo.IPADDRESS+":8080"+"/examples/Q-d-Bay/web/Android/registeration.jsp");
			
			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
			StrictMode.setThreadPolicy(policy); 
		    ArrayList<NameValuePair> n= new ArrayList<NameValuePair>();
		    n.add(new BasicNameValuePair("customer_name",customer_name));
		    n.add(new BasicNameValuePair("emailid",emailid));
		    n.add(new BasicNameValuePair("address",address));
		    n.add(new BasicNameValuePair("phone_number",phone_number));
		    n.add(new BasicNameValuePair("utype", "customer"));
		    n.add(new BasicNameValuePair("password",password));
		    n.add(new BasicNameValuePair("appcode",imei));
		    //Toast.makeText(getBaseContext(), "ssskkkk", Toast.LENGTH_LONG).show();
			
		    httppost.setEntity(new UrlEncodedFormEntity(n));
	        ResponseHandler<String> res=new BasicResponseHandler();
		    final String data = httpclient.execute(httppost, res);
		     // Toast.makeText(getBaseContext(), data, Toast.LENGTH_LONG).show();
    		
		    JSONArray jarray=new JSONArray(data);
		     //JSONObject jobj = new JSONObject();
			JSONObject json_data=jarray.getJSONObject(0);
	    	String status=json_data.getString("status");
	    	String count=json_data.getString("count");
	    	
	    	 //Toast.makeText(getBaseContext(), status+count, Toast.LENGTH_LONG).show();
	    	if(count.equals("0"))
	    	{
	    		if(status.equals("success"))
	    		{
	    			
	    			 Toast.makeText(getBaseContext(), "Successfully Registered", Toast.LENGTH_LONG).show();
	    		     Intent in=new Intent(getApplicationContext(),Login.class);
	    		     startActivity(in);
	    		}
	    		else
	    		{
	    			
	    			 Toast.makeText(getBaseContext(),"Not Inserted Try again", Toast.LENGTH_LONG).show();
	    		    	
	    		}
	    		
	    	}
	    	else
	    	{
	    		 Toast.makeText(getBaseContext(), "Email Already exist Try again", Toast.LENGTH_LONG).show();
	 	    	 
	    		
	    	}
		      
		}
		catch(Exception e)
		{
			
			//Toast.makeText(getApplicationContext(),"dddd"+e.getMessage(),Toast.LENGTH_LONG).show();
			
		}
	     }
		
	}

}
