package com.example.hipermart;

import java.util.ArrayList;

import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Feedback extends Activity {
	HttpClient httpclient;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_feedback);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.feedback, menu);
		return true;
	}
	@SuppressLint("NewApi")
	public void feedbackbtn(View v)
	{
	EditText et=(EditText)findViewById(R.id.msgid);
	String msg=et.getText().toString();
//	Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
	try
	{ 
		Intent i = new Intent( Intent.ACTION_VIEW, Uri.parse ("http://"+LoginInfo.IPADDRESS+":8080"+"/examples/Q-d-Bay/web/android/registeration.jsp"));
	  // startActivity(i);
		 //Toast.makeText(getBaseContext(), "http://"+LoginInfo.IPADDRESS+":8080"+"/examples/sb/Q-R-D-Bay-Server/web/android/registeration.jsp", Toast.LENGTH_LONG).show();
		httpclient=new DefaultHttpClient();
		HttpPost httppost= new HttpPost("http://"+LoginInfo.IPADDRESS+":8080"+"/examples/Q-d-Bay/web/Android/feedback.jsp");
		
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		StrictMode.setThreadPolicy(policy); 
	    ArrayList<NameValuePair> n= new ArrayList<NameValuePair>();
	    n.add(new BasicNameValuePair("msg",msg));
	    n.add(new BasicNameValuePair("from_id",LoginInfo.USERNAME));
	       // Toast.makeText(getBaseContext(), "ssskkkk", Toast.LENGTH_LONG).show();
		
	    httppost.setEntity(new UrlEncodedFormEntity(n));
        ResponseHandler<String> res=new BasicResponseHandler();
	    final String data = httpclient.execute(httppost, res);
	     //Toast.makeText(getBaseContext(), data, Toast.LENGTH_LONG).show();
		
	    JSONArray jarray=new JSONArray(data);
	     //JSONObject jobj = new JSONObject();
		JSONObject json_data=jarray.getJSONObject(0);
    	String status=json_data.getString("status");
    	  
    		if(status.equals("success"))
    		{
    			
    			 Toast.makeText(getBaseContext(), "Successfully Registered", Toast.LENGTH_LONG).show();
    		     Intent in=new Intent(getApplicationContext(),Login.class);
    		     startActivity(in);
    		}
    		else
    		{
    			
    			 Toast.makeText(getBaseContext(),"Not Inserted Try again", Toast.LENGTH_LONG).show();
    		    	
    		}
    	 
	}
	catch(Exception e)
	{
		
		//Toast.makeText(getApplicationContext(),"dddd"+e.getMessage(),Toast.LENGTH_LONG).show();
		
	}	 
		
	}
	
}
