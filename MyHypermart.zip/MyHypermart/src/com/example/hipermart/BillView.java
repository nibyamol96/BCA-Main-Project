package com.example.hipermart;

import java.util.ArrayList;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;
 
import android.os.Bundle;
import android.os.StrictMode;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class BillView extends Activity {

	HttpPost httppost;
	HttpResponse response;

	HttpClient httpclient;
	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_bill_view);
		
		TextView bno=(TextView)findViewById(R.id.billno);
		TextView total=(TextView)findViewById(R.id.total);
		
		TextView bdate=(TextView)findViewById(R.id.billdate);
		
		try
		{        
			          
		httpclient=new DefaultHttpClient(); 
		httppost= new HttpPost("http://"+LoginInfo.IPADDRESS+":8080"+"/examples/Q-d-Bay/web/Android/viewbill.jsp");
			          
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		StrictMode.setThreadPolicy(policy); 		
		  ArrayList<NameValuePair> n= new ArrayList<NameValuePair>();
			
			 
			 n.add(new BasicNameValuePair("email",LoginInfo.USERNAME.toString()));
			httppost.setEntity(new UrlEncodedFormEntity(n));
	  				
		ResponseHandler<String> res=new BasicResponseHandler();
					
		final String data = httpclient.execute(httppost, res);
		
		JSONArray jarray=new JSONArray(data);

		//Toast.makeText(getApplicationContext(),data , Toast.LENGTH_LONG).show();
						
		int len=jarray.length();

		for(int i=0;i<len;i++)
						
		{						
			Product p=new Product();			
			JSONObject json_data=jarray.getJSONObject(i);
			String billno=json_data.getString("billno");
			String bdat=json_data.getString("billno");
			String tot=json_data.getString("total");
			bno.setText(json_data.getString("billno").trim());
			
			total.setText(json_data.getString("total").trim());
			bdate.setText(json_data.getString("bdate").trim());
			//Toast.makeText(getApplicationContext(),billno+bdat, Toast.LENGTH_LONG).show();
		}
		//finish();
		//String tot=p.grandtotal+"";
		//total.setText(tot);		
		}catch(Exception e)
		{
			//	Toast.makeText(getApplicationContext(),e.getMessage(), Toast.LENGTH_LONG).show();
		}
	}
	@Override
	public void onBackPressed()
	{
	    super.onBackPressed(); 
	    startActivity(new Intent(getApplicationContext(),MainActivity.class));
	    finish();

	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.bill_view, menu);
		return true;
	}
	public void feedbackbtn(View v)
	{
		Intent intent=new Intent(getApplicationContext(),Feedback.class);
	    startActivity(intent);
	}
	public void exit(View v)
	{
		Intent intent=new Intent(getApplicationContext(),MainActivity.class);
	    startActivity(intent);
	}

}
