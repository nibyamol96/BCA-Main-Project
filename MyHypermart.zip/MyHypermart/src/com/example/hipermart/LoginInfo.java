package com.example.hipermart;

public class LoginInfo {
	public static String USERNAME;
	public static String IPADDRESS="192.168.43.118";
	public static String UType;
	public static String Phonenumber;
}
