package com.example.hipermart;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
 
public class CartAdapter extends BaseAdapter {
	private Context mContext;

	 ArrayList<Product> list;
	    public CartAdapter(Context c, ArrayList<Product> list) {
	        mContext = c;
	        this.list = list;
	    }

	    @Override
	    public int getCount() {
	        // TODO Auto-generated method stub
	        return list.size();
	    }

	    @Override
	    public Object getItem(int position) {
	        // TODO Auto-generated method stub
	        return null;
	    }

	    @Override
	    public long getItemId(int position) {
	        // TODO Auto-generated method stub
	        return 0;
	    }

	 

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		 View grid;
	        LayoutInflater inflater = (LayoutInflater) mContext
	                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

	        if (convertView == null) {

	            grid = new View(mContext);
	            grid = inflater.inflate(R.layout.cartitems, null);
	            TextView tpname = (TextView) grid.findViewById(R.id.txtproductname);
	            TextView ttprice = (TextView) grid.findViewById(R.id.txttotalamount);
	              
	            tpname.setText(list.get(position).pname);
	            ttprice.setText(list.get(position).qry +"x"+list.get(position).price+"="+list.get(position).getTotal());
	            
	            ImageView img = (ImageView) grid.findViewById(R.id.productimage);
	              
		        img.setImageBitmap(list.get(position).image);  
	          //  textView.setText(list.get(position).pname);
	          //  TextView textprice = (TextView) grid.findViewById(R.id.txtcartshowgrandtotal);
	          // textprice.setText("Total= "+list.get(position).qry +" x " +list.get(position).price+"="+list.get(position).getTotal());
	              
	               
	               
	              
	              
	              } else {
	            grid = (View) convertView;
	        }

	        return grid;

	}
	}
