package com.example.hipermart;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;
 

import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ContextMenu.ContextMenuInfo;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.AdapterContextMenuInfo;

public class ProductCartList extends Activity {
	HttpPost httppost;
	HttpResponse response;
	String pgm,sch,cart_id;
	HttpClient httpclient;
	ArrayList<String> selectedItems;
	ListView  lv1, lv2, lv3, lv4;
	Intent i;
	int d;
	String id;
	String pcode,qty;
	final Context context = this;
	long cid;
	ArrayList<Product> list_pcode ;
	double grandtotal;
	String response1;
	int quantity=0;
	@TargetApi(Build.VERSION_CODES.GINGERBREAD)
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_show_cart);  
		
		//Toast.makeText(getApplicationContext(), root, Toast.LENGTH_LONG).show();
		
		// Button b=(Button)findViewById(R.id.button1);
		
		 final Context context = this;
				
		//Toast.makeText(getApplicationContext(),"wrking",Toast.LENGTH_LONG).show();
		
 	 search();
			
 	 
 	 

			
				
	}
	@Override
	public void onBackPressed()
	{
	    super.onBackPressed(); 
	    startActivity(new Intent(getApplicationContext(),UserHome.class));
	    finish();

	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.show_cart, menu);
		return true;
	}

 
	@SuppressLint("NewApi")
	public void submit(View v) {
		
		
		/*if(grandtotal==0)
		{
			Toast.makeText(getApplicationContext(), grandtotal+"<<<Sorry No Products You carted", Toast.LENGTH_LONG).show();
			
			Intent in =new Intent(getApplicationContext(),UserHome.class);
			 startActivity(in);
		}*/
		
		try{
			
			 httpclient=new DefaultHttpClient();
			// httppost= new HttpPost("http://10.0.2.2:8081/examples/addtobill.jsp"); 
			 httppost= new HttpPost("http://"+LoginInfo.IPADDRESS+":8080"+"/examples/Q-d-Bay/web/Android/addtobill.jsp");
				
			 
			 StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		  	    StrictMode.setThreadPolicy(policy); 
		  	    
		  	  ArrayList<NameValuePair> n= new ArrayList<NameValuePair>();
				
				n.add(new BasicNameValuePair("amount",String.valueOf(grandtotal).trim()));
				n.add(new BasicNameValuePair("email",LoginInfo.USERNAME));
				
				httppost.setEntity(new UrlEncodedFormEntity(n));
		  		
				ResponseHandler<String> res=new BasicResponseHandler();
				
				final String data = httpclient.execute(httppost, res);
		

			// Toast.makeText(getApplicationContext(),data,Toast.LENGTH_LONG).show();
				
				

				JSONArray jarray=new JSONArray(data);

				JSONObject json_data=jarray.getJSONObject(0);
				String billno=json_data.getString("billno");
				//Toast.makeText(getApplicationContext(),billno,Toast.LENGTH_LONG).show();
				
				
				/*for(int i=1;i<list_pcode.size();i++){
					 pcode=list_pcode.get(i);
					qty=list_qty.get(i);
				addtopd(billno,pcode,qty);
					}*/
				Product p=new Product();
				for(Product p1: list_pcode)
				{
					addtopd(billno,p1);
					
				}
				
				
			}
				catch(Exception e)
				{
					 Toast.makeText(ProductCartList.this,e.toString(), Toast.LENGTH_SHORT).show();
				}
	        
	}
	@SuppressLint("NewApi")
	void addtopd(String billno,Product p){
		try{
			// Toast.makeText(ProductCartList.this,"addtopd", Toast.LENGTH_SHORT).show();
				
			 httpclient=new DefaultHttpClient();
			// httppost= new HttpPost("http://10.0.2.2:8081/examples/addtopd.jsp"); 
		  	
			  httppost= new HttpPost("http://"+LoginInfo.IPADDRESS+":8080"+"/examples/Q-d-Bay/web/Android/addtopd.jsp");
				
			 StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		  	    StrictMode.setThreadPolicy(policy); 
		  	    
		  	  ArrayList<NameValuePair> n= new ArrayList<NameValuePair>();
				
				n.add(new BasicNameValuePair("billno",billno));
				n.add(new BasicNameValuePair("pcode",p.pid));
				n.add(new BasicNameValuePair("qty",p.qry));
				 n.add(new BasicNameValuePair("email",LoginInfo.USERNAME.toString()));
				httppost.setEntity(new UrlEncodedFormEntity(n));
		  		
				ResponseHandler<String> res=new BasicResponseHandler();
				
				final String data = httpclient.execute(httppost, res);

				JSONArray jarray=new JSONArray(data);

				JSONObject json_data=jarray.getJSONObject(0);
				String bno=json_data.getString("billno");
		 //Toast.makeText(getApplicationContext(),"add to pd"+data,Toast.LENGTH_LONG).show();
				
				Intent in =new Intent(getApplicationContext(),BillView.class);
			    startActivity(in);
			}
				catch(Exception e)
				{
					 //Toast.makeText(ProductCartList.this,e.toString(), Toast.LENGTH_SHORT).show();
				}
	}
	@SuppressLint("NewApi")
	public void search(){
		
		
		try{
			String name="";
		list_pcode	= new ArrayList<Product>();
			
			
			// ArrayAdapter<String> adp= new ArrayAdapter<String>(this,R.layout.activity_cart_list,list);
			// lv.setAdapter(adp);	
		//Intent i = new Intent( Intent.ACTION_VIEW, Uri.parse ("http://"+LoginInfo.IPADDRESS+":8080"+"/examples/Q-d-Bay/web/Android/cartinfolist.jsp"));
		//  startActivity(i);
			
			 httpclient=new DefaultHttpClient();
			 // httppost= new HttpPost("http://"+LoginInfo.IPADDRESS+":8080"+"/examples/sb/Q-R-D-Bay-Server/web/android/cartinfolist.jsp");
			  httppost= new HttpPost("http://"+LoginInfo.IPADDRESS+":8080"+"/examples/Q-d-Bay/web/Android/cartinfolist.jsp");
		       
			// httppost= new HttpPost("http://10.0.2.2:8081/examples/cartinfolist.jsp"); 
		  		//httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
		  		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		  	    StrictMode.setThreadPolicy(policy); 
		  	  ArrayList<NameValuePair> n= new ArrayList<NameValuePair>();
				

		  	  n.add(new BasicNameValuePair("email",LoginInfo.USERNAME.toString()));
		  	httppost.setEntity(new UrlEncodedFormEntity(n));
				ResponseHandler<String> res=new BasicResponseHandler();
				
				final String data = httpclient.execute(httppost, res);
		

			 //  Toast.makeText(getApplicationContext(),data,Toast.LENGTH_LONG).show();
				
				

				JSONArray jarray=new JSONArray(data);

			//	int len=jarray.length();
				int len=jarray.length();
				 if(len==0)
				 {
					 Toast.makeText(getApplicationContext(), "No Products You carted", Toast.LENGTH_LONG).show();
						 
					 Intent in =new Intent(getApplicationContext(),UserHome.class);
					// startActivity(in);
					 
				 }
				 else
				 {
					 for(int i=0;i<len;i++)
							
						{	
				 		  //  Toast.makeText(getApplicationContext(),i+" length->>"+len,Toast.LENGTH_LONG).show();
							JSONObject json_data=jarray.getJSONObject(i);
							String pcode=json_data.getString("pcode");
							String pname=json_data.getString("pname");
							String qty=json_data.getString("qty");	
							String tot=json_data.getString("tot");
							  quantity=json_data.getInt("quantity");
							
							//Toast.makeText(getApplicationContext(),pcode+pname+qty+tot+"",Toast.LENGTH_LONG).show();
							
						 String encodedImage=json_data.getString("image");
						  byte[] decodedString = Base64.decode(encodedImage, Base64.DEFAULT);
			             Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
			             
			             //View imageView=findViewById(R.id.imageView1);
			            // ImageView image=(ImageView) findViewById(R.id.imageView1);
			             //image.setImageBitmap(decodedByte);
			            // SaveImage(decodedByte);
			             
						
						Product p=new Product();
						p.pname=pname;
						p.price=tot;
						p.qry=qty;
						p.pid=pcode;
						
					 p.image=decodedByte;
						
						list_pcode.add(p);
			            grandtotal+= p.getTotal();
			        //Toast.makeText(getApplicationContext(),decodedByte+"<<<--decode",Toast.LENGTH_LONG).show();
						
						} 
				 }
				
				 
				// Toast.makeText(getApplicationContext(), "search working",Toast.LENGTH_LONG).show();
				 lv1=(ListView)findViewById(R.id.listView1);

				 CartAdapter adp = new CartAdapter(getApplicationContext(), list_pcode);

				 
				lv1.setAdapter(adp); 
				adp.notifyDataSetChanged();
				
				

				String string = "\u20B9";
				byte[] utf8 = null;
				try {
					utf8 = string.getBytes("UTF-8");
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					string = new String(utf8, "UTF-8");
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
		TextView txtgtotal = (TextView) findViewById(R.id.totalamount);
		// txtgtotal.notifyDataSetChanged();
		txtgtotal.setText("Total=  "+string+grandtotal+"");
		// txtgtotal.notifyDataSetChanged();
		if(grandtotal==0)
		{
			txtgtotal.setText("");
			Toast.makeText(getApplicationContext(), "No Products You carted", Toast.LENGTH_LONG).show();
		}

				 registerForContextMenu(lv1);	
				 //notifyDataSetChanged();
						 
						
						
		 
				
			}
				catch(Exception e)
				{
					//Toast.makeText(ProductCartList.this,e.toString()+"nnnnnnnnn", Toast.LENGTH_SHORT).show();
				}
	}
	public void addmore(View v)
	{
		UserHome uh=new UserHome();
		// uh.scanQr(v);
		Intent ii=new Intent(getApplicationContext(),UserHome.class);
	    startActivity(ii);
		
	}
	
	 @Override   
	    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo)  
	    {  
	            super.onCreateContextMenu(menu, v, menuInfo);  
	            menu.setHeaderTitle("Select The Action");    
	            menu.add(0, v.getId(), 0, "Edit");//groupId, itemId, order, title   
	            menu.add(0, v.getId(), 0, "Delete");   
	    }
	 
	 @Override
		public boolean onContextItemSelected(MenuItem item) {
			String title= item.getTitle().toString();
	    	AdapterContextMenuInfo info = 
	    			(AdapterContextMenuInfo) item.getMenuInfo();
	    	 
	    	if(title.equals("Delete"))
	    	{
	    	    final int position=  (int) info.position;	
				    	
				    	    
				    	    AlertDialog.Builder builder = new
				    	    		AlertDialog.Builder(this);
				    	    
				    	    builder.setMessage("Are you sure you want to Delete?");
				    	    
				    	    builder.setPositiveButton("YES",   new DialogInterface.OnClickListener() {
								
								@Override
								public void onClick(DialogInterface arg0, int arg1) {
									// TODO Auto-generated method stub
									
									 delete(position);
									
								}
							});
				    	    		
				    	    		 builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
				    	    		 public void onClick(DialogInterface dialog, int id) {
				    	    		 dialog.cancel();
				    	    		 }
				    	    		 });
				    	    		AlertDialog alert = builder.create();
				    	    alert.show();
				    	    
				              //  delete(position);
				    	}
	    	else if(title.equals("Edit"))
	    	{
	    		 final int position=  (int) info.position;	
	    		LayoutInflater li = LayoutInflater.from(context);
	    		View promptsView = li.inflate(R.layout.prompts, null);
	    		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);

				// set prompts.xml to alertdialog builder
				alertDialogBuilder.setView(promptsView);

				final EditText userInput = (EditText) promptsView.findViewById(R.id.editTextDialogUserInput);

				// set dialog message
	    		alertDialogBuilder
				.setCancelable(false)
				.setPositiveButton("OK",
				  new DialogInterface.OnClickListener() {
				    public void onClick(DialogInterface dialog,int id) {
					// get user input and set it to result
					// edit text
				    	
				    	final String _qty=userInput.getText().toString();
				    	int nqnty=Integer.parseInt(_qty);
				    	if(nqnty>quantity)
				    	{
				    		Toast.makeText(getApplicationContext(), "Sorry This Quantity Not Available Now Only Avaliable "+quantity, Toast.LENGTH_LONG).show();
							  
				    		
				    	}
				    	else
				    	{
				    		
				    		//Toast.makeText(getApplicationContext(), _qty, Toast.LENGTH_LONG).show();
						   	edit(position,_qty);
						    	
				    	}
				    	
				    	
				    	
				    	
					
				    }
				  })
				.setNegativeButton("Cancel",
				  new DialogInterface.OnClickListener() {
				    public void onClick(DialogInterface dialog,int id) {
					dialog.cancel();
				    }
				  });

			// create alert dialog
			AlertDialog alertDialog = alertDialogBuilder.create();

			// show it
			alertDialog.show(); 
	    	}
				    	return true;
				    	
	}
	 @SuppressLint("NewApi")
	private void edit(int position,String _qty)
	    {
	    	  //String _pcode= list_pcode.get(position);
		   Product s= list_pcode.get(position);
	    	 try
	     	{
	    		// Toast.makeText(getApplicationContext(), "pid>>"+s.pid+">>"+_qty, Toast.LENGTH_LONG).show();
	    		 httpclient=new DefaultHttpClient();
					
					//httppost= new HttpPost("http://10.0.2.2:8081/examples/cartitemedit.jsp"); 
					  httppost= new HttpPost("http://"+LoginInfo.IPADDRESS+":8080"+"/examples/Q-d-Bay/web/Android/cartitemedit.jsp");
							          
					StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
					StrictMode.setThreadPolicy(policy); 
							  	
					ArrayList<NameValuePair> n= new ArrayList<NameValuePair>();
					
					n.add(new BasicNameValuePair("pcode",s.pid));
					n.add(new BasicNameValuePair("qty",_qty));
					n.add(new BasicNameValuePair("email",LoginInfo.USERNAME));
					
					httppost.setEntity(new UrlEncodedFormEntity(n));
					
					ResponseHandler<String> res=new BasicResponseHandler();
						
		          response1 = httpclient.execute(httppost,res).trim();
		          Toast.makeText(ProductCartList.this,response1+"Successfully updated", Toast.LENGTH_LONG).show();
		          grandtotal=0;
		         search();
	     	
	     	}

  	 
		  	catch(Exception e)
		  	{
		  		
		  	}

      }
	 @SuppressLint("NewApi")
	private void delete(int position)
	    {
		 Product s= list_pcode.get(position);
	    	
	    	 
	    	 try
	     	{
	    		
	     	    httpclient=new DefaultHttpClient();
				
				//httppost= new HttpPost("http://10.0.2.2:8081/examples/cartitemdelete.jsp"); 
				  httppost= new HttpPost("http://"+LoginInfo.IPADDRESS+":8080"+"/examples/Q-d-Bay/web/Android/cartitemdelete.jsp");
						          
				StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
				StrictMode.setThreadPolicy(policy); 
						  	
				ArrayList<NameValuePair> n= new ArrayList<NameValuePair>();
				
				n.add(new BasicNameValuePair("pcode",s.pid));
				n.add(new BasicNameValuePair("email",LoginInfo.USERNAME));
				httppost.setEntity(new UrlEncodedFormEntity(n));
				
				ResponseHandler<String> res=new BasicResponseHandler();
					
	          response1 = httpclient.execute(httppost,res).trim();
	          Toast.makeText(ProductCartList.this,">>"+response1+"<<<<Item removed from your cart", Toast.LENGTH_LONG).show();
	         grandtotal=0;
	          search();
			
	     	}
	     	catch(Exception e)
	     	{
	     		
	     	}

	    }

}
