package com.example.hipermart;
 

import java.util.ArrayList;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import android.os.Bundle;
import android.os.StrictMode;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class IpActivity extends Activity {
	EditText et;
	HttpPost httppost;
    StringBuffer buffer;
    HttpResponse response;
    HttpClient httpclient;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_ip);
		 et=(EditText) findViewById(R.id.editText1);
		  et.setText("192.168.1.8");
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.ip, menu);
		return true;
	}
	
	public void ipbtn(View v)
	{
		 
		String ip=et.getText().toString();
		LoginInfo.IPADDRESS=ip; 
		String status=checklogin();
		//if(status.equals("true"))
		{
			
			Intent ii=new Intent(getApplicationContext(),UserHome.class);
			//ii.putExtra("email",LoginInfo.USERNAME);
			//startActivity(ii);
		}
	//	else
		{
			//Toast.makeText(getApplicationContext(), LoginInfo.IPADDRESS, Toast.LENGTH_LONG).show();
			Intent i=new Intent(getApplicationContext(),Login.class);
			startActivity(i);
			
		}
		
		
	}
	@SuppressLint("NewApi")
	public String checklogin()
	{
		String status="true";
		
		try
		{ 
			//Intent i = new Intent( Intent.ACTION_VIEW, Uri.parse ("http://"+LoginInfo.IPADDRESS+":8080"+"/examples/Q-R-D-Bay/web/android/registeration.jsp"));
			//startActivity(i);

		     TelephonyManager telephonyManager = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
		     String imei=telephonyManager.getDeviceId();
				

			httpclient=new DefaultHttpClient();
			HttpPost httppost= new HttpPost("http://"+LoginInfo.IPADDRESS+":8080"+"/examples/Q-d-Bay/web/Android/checklogin.jsp");
			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
			StrictMode.setThreadPolicy(policy); 
		    ArrayList<NameValuePair> n= new ArrayList<NameValuePair>();
		    n.add(new BasicNameValuePair("appcode",imei));
		    
		    
		    httppost.setEntity(new UrlEncodedFormEntity(n));
	        ResponseHandler<String> res=new BasicResponseHandler();
		    final String data = httpclient.execute(httppost, res);
		    
		   // Toast.makeText(getApplicationContext(),data,Toast.LENGTH_LONG).show();
			
		    JSONObject jobj = new JSONObject(data);
		    String status1=jobj.getString("status");
		    if(status1.equals("true"))
		    {
		    	Toast.makeText(getApplicationContext(),"Succesfully Login",Toast.LENGTH_LONG).show();
				 
		    	Intent ii=new Intent(getApplicationContext(),UserHome.class);
				ii.putExtra("email",LoginInfo.USERNAME);
				startActivity(ii);
		    }
		    else
		    {
		    	
		    	Toast.makeText(getApplicationContext(),"Invalid user",Toast.LENGTH_LONG).show();
				
		    }
		}
		catch(Exception e)
		{
			status=e.getMessage();
			//Toast.makeText(getApplicationContext(), e.getMessage(),Toast.LENGTH_LONG).show();
		}
		return status;
		
	}
}
