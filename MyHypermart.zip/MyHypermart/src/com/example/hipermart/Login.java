package com.example.hipermart;

import java.util.ArrayList;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

 
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends Activity {
	HttpPost httppost;
    StringBuffer buffer;
    HttpResponse response;
    HttpClient httpclient;
    String username,password;
    EditText et,et2;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		
		 et=(EditText)findViewById(R.id.editText1);
		 et2=(EditText)findViewById(R.id.editText2);
		 et.setText("n@gmail.com");
	}
	@Override
	public void onBackPressed()
	{
	    super.onBackPressed(); 
	    startActivity(new Intent(getApplicationContext(),UserHome.class));
	    finish();

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.login, menu);
		return true;
	}
	public void registernow(View v)
	{
		//Toast.makeText(getApplicationContext(), "ss", Toast.LENGTH_LONG).show();
		 Intent i=new Intent(getApplication(),Registration.class);
		 startActivity(i);
		
	}
	
	@SuppressLint("NewApi")
	public void login(View v)
	{
		 
		String username=et.getText().toString().trim();
		String password=et2.getText().toString().trim();
		//Toast.makeText(getApplicationContext(), username+password, Toast.LENGTH_LONG).show();
		
		try
		{ 
			Intent i = new Intent( Intent.ACTION_VIEW, Uri.parse ("http://"+LoginInfo.IPADDRESS+":8080"+"/examples/Q-d-Bay/web/Android/login.jsp"));
			//startActivity(i);

			httpclient=new DefaultHttpClient();
			HttpPost httppost= new HttpPost("http://"+LoginInfo.IPADDRESS+":8080"+"/examples/Q-d-Bay/web/Android/login.jsp");
			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
			StrictMode.setThreadPolicy(policy); 
		    ArrayList<NameValuePair> n= new ArrayList<NameValuePair>();
		    n.add(new BasicNameValuePair("username",username));
		    n.add(new BasicNameValuePair("password",password));
		    
		    httppost.setEntity(new UrlEncodedFormEntity(n));
	        ResponseHandler<String> res=new BasicResponseHandler();
		    final String data = httpclient.execute(httppost, res);
		    
		 //  Toast.makeText(getApplicationContext(),data,Toast.LENGTH_LONG).show();
			
		    JSONObject jobj = new JSONObject(data);
		    String status=jobj.getString("status");
		    if(status.equals("true"))
		    {
		    	Toast.makeText(getApplicationContext(),"Succesfully Login",Toast.LENGTH_LONG).show();
				LoginInfo.USERNAME=username;
		    	Intent ii=new Intent(getApplicationContext(),UserHome.class);
		        ii.putExtra("email",username);
				startActivity(ii);
		    }
		    else
		    {
		    	
		    	Toast.makeText(getApplicationContext(),"Invalid user",Toast.LENGTH_LONG).show();
				
		    }
		}
		catch(Exception e)
		{
			
			//Toast.makeText(getApplicationContext(), e.getMessage(),Toast.LENGTH_LONG).show();
		}
		
		 

	}
	
	public void password(View v)
	{
		//Intent ii=new Intent(getApplicationContext(),Forgotpassword.class);
		Intent i = new Intent( Intent.ACTION_VIEW, Uri.parse ("http://"+LoginInfo.IPADDRESS+":8080"+"/examples/Q-d-Bay/web/forgotpassword.jsp"));
		startActivity(i);
	
	}
}