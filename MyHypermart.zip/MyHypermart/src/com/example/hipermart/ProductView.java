package com.example.hipermart;

import java.util.ArrayList;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;
 

import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ProductView extends Activity {
	 TextView p,q,md,ed,pr,mf,d,t8;
	 EditText et1;
	 String pid;
	 int quantity=0;
	 Button b1;
	 int qty;
	 HttpPost httppost;
		HttpResponse response;
		HttpClient httpclient;
		String response1;
		Intent i;
		int x=0,y=0,z=0;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_product_view);
		
		p=(TextView) findViewById(R.id.pname);
		 
		md=(TextView) findViewById(R.id.mandate);
		ed=(TextView) findViewById(R.id.expdate);
		pr=(TextView) findViewById(R.id.price);
		mf=(TextView) findViewById(R.id.manuf);
		d=(TextView) findViewById(R.id.desc); 
		 et1=(EditText) findViewById(R.id.cartitem);
		String qrdate="";
		 i=getIntent();
		 if(i!=null)
			{
				 qrdate=i.getStringExtra("qrdata");
				
			}
	  //Toast.makeText(getApplicationContext(), qrdate+"qrdate", Toast.LENGTH_LONG).show();
	     getdetails(qrdate);
	     
	     
	     b1=(Button) findViewById(R.id.cartbtn);
	     b1.setOnClickListener(new View.OnClickListener() {
			
			@SuppressLint("NewApi")
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
			//  Toast.makeText(getApplicationContext(), "btn click", Toast.LENGTH_LONG).show();
				try
				{        
					          
					String tid=et1.getText().toString();
					int nqnty=0;
					try{
					  nqnty=Integer.parseInt(tid);
					
					}
					catch(Exception e){
						et1.setError("Required Quantity"+e.getMessage());
					}
					if(tid.equals(""))
					{
		
					
						et1.setError("Required Quantity");
					
						
					}
					
					else if(nqnty>quantity)
					{
						et1.setError("Sorry This Quantity Not Available Now Only Avaliable "+quantity+"");
						
						
					}
					else if(nqnty==0)
					{
						et1.setError("Sorry pleaseenter valid Quantity ");
						
						
					}
					else
					{
					Intent i = new Intent( Intent.ACTION_VIEW, Uri.parse ("http://"+LoginInfo.IPADDRESS+":8080"+"/examples/sb/Q-R-D-Bay-Server/web/android/cartdetails.jsp"));
				//  startActivity(i);
					
					 //Toast.makeText(getApplicationContext(), tid+"kk",Toast.LENGTH_LONG).show();
					
					httppost= new HttpPost("http://"+LoginInfo.IPADDRESS+":8080"+"/examples/Q-d-Bay/web/Android/cartdetails.jsp");
			          
					StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
					StrictMode.setThreadPolicy(policy); 
							  	
					ArrayList<NameValuePair> n= new ArrayList<NameValuePair>();
					
					n.add(new BasicNameValuePair("product_name", p.getText().toString()));
					n.add(new BasicNameValuePair("product_id",pid));
					n.add(new BasicNameValuePair("price", pr.getText().toString()));
					n.add(new BasicNameValuePair("qty", et1.getText().toString()));
					n.add(new BasicNameValuePair("emailid",LoginInfo.USERNAME.toString()));
					x=Integer.parseInt(pr.getText().toString());
					y=Integer.parseInt(et1.getText().toString());
					z=x*y;
					String t = String.valueOf(z);
				//	Toast.makeText(getApplicationContext(), t,Toast.LENGTH_LONG).show();
					n.add(new BasicNameValuePair("tot",t));

					httppost.setEntity(new UrlEncodedFormEntity(n));
									
					ResponseHandler<String> res=new BasicResponseHandler();
								
					
					
		         //    response1 = httpclient.execute(httppost,res);
					 final String data = httpclient.execute(httppost, res);
          //  Toast.makeText(getApplicationContext(),data+"<<--",Toast.LENGTH_LONG).show();
						
		            	
					
					  JSONArray jarray=new JSONArray(data);
					     //JSONObject jobj = new JSONObject();
						JSONObject json_data=jarray.getJSONObject(0);
				    	String status=json_data.getString("cartiteminsertion");
				    	String checkCartExist=json_data.getString("checkCartExist");
					if(status.equals("success"))
					{
						 Toast.makeText(getApplicationContext(),"Item added to cart",Toast.LENGTH_LONG).show();
							et1.setText("");
						
						/// Toast.makeText(getApplicationContext(),"success",Toast.LENGTH_LONG).show();
							
					 Intent intent=new Intent(getApplicationContext(),ProductCartList.class);
						  startActivity(intent);
						
					}
					if(checkCartExist.equals("false"))
					{
						 Toast.makeText(getApplicationContext(),"Item already carted...",Toast.LENGTH_LONG).show();
						  Intent intent=new Intent(getApplicationContext(),ProductCartList.class);
						  startActivity(intent);	
						
					}
					}
					
				httpclient=new DefaultHttpClient();
				}
				catch(Exception e)
				{
					//Toast.makeText(getApplicationContext(),"btnerror"+e.getMessage(),Toast.LENGTH_LONG).show();
					
					
				}
				
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.product_view, menu);
		return true;
	}
	@SuppressLint("NewApi")
	void getdetails(String qrdata)
	{
	    	  
		         
	try
	{        
		          
	httpclient=new DefaultHttpClient();
 Intent ii = new Intent( Intent.ACTION_VIEW, Uri.parse ("http://"+LoginInfo.IPADDRESS+":8080"+"/examples/Q-R-D-Bay/web/android/viewdetails.jsp"));
	// startActivity(i);

	
	// httppost= new HttpPost("http://10.0.2.2:8081/examples/Process_Request.jsp"); 
	HttpPost httppost= new HttpPost("http://"+LoginInfo.IPADDRESS+":8080"+"/examples/Q-d-Bay/web/Android/viewdetails.jsp");
		          
	StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
	StrictMode.setThreadPolicy(policy); 
			  	
	ArrayList<NameValuePair> n= new ArrayList<NameValuePair>();
	//Toast.makeText(getApplicationContext(),qrdata,Toast.LENGTH_LONG).show();	          
	n.add(new BasicNameValuePair("qrdata", qrdata));

	httppost.setEntity(new UrlEncodedFormEntity(n));
					
	ResponseHandler<String> res=new BasicResponseHandler();
				
	final String data = httpclient.execute(httppost, res);
	
	JSONArray jarray=new JSONArray(data);
	//JSONObject jobj=new JSONObject(data);
	//JSONObject json_data=jarray.getJSONObject(0);
	//String qrd=json_data.getString("qrdate").toString();
	
  //  Toast.makeText(getApplicationContext(), data+"data",Toast.LENGTH_LONG).show();
	 
	
	 int len=jarray.length();
	// Toast.makeText(getApplicationContext(),"lenght=>"+len,Toast.LENGTH_LONG).show();
	 
		
	 for(int i=0;i<len;i++)
					
	{						
					
	JSONObject json_data=jarray.getJSONObject(i);
	
	String product_name=json_data.getString("product_name");
	String manufacturingdate=json_data.getString("manufacturingdate");
	String expirydate=json_data.getString("expirydate");
	String price=json_data.getString("price");
	String manufacturer=json_data.getString("manufacturer");
	String description=json_data.getString("description");	
	String image=json_data.getString("image");
	quantity=json_data.getInt("quantity");
	
	p.setText(json_data.getString("product_name"));
	md.setText(json_data.getString("manufacturingdate"));
	ed.setText(json_data.getString("expirydate"));
	pr.setText(json_data.getString("price"));
	mf.setText(json_data.getString("manufacturer"));
	d.setText(json_data.getString("description"));
	pid=(json_data.getString("product_id"));
//	Toast.makeText(getApplicationContext(), product_name, Toast.LENGTH_LONG).show();
 
	} 
						
	 
				
	}catch(Exception e)
	{
		//Toast.makeText(getApplicationContext(),">>>>"+ e.getMessage(),Toast.LENGTH_LONG).show();	
	}
  }


}
