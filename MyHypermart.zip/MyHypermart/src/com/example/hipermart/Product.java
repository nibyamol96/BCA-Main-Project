package com.example.hipermart;

import android.graphics.Bitmap;

 
	public class Product {

		public String pid;
		public String pname;
		public String price="0";
		public Bitmap image;
		 
		public String qry="0";
		
		public double total  ;
		
		public static double grandtotal;
		
		public double getTotal()
		{
			return total= (Double.parseDouble(price)) * (Integer.parseInt(qry))  ;
			
		}
}
