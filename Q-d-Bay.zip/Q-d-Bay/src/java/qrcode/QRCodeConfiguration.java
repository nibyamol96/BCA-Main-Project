/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package qrcode;

import com.google.zxing.BarcodeFormat;

/**
 *
 * @author CollaborativeClouds Software Solutions
 * <www.collaborativeclouds.com>
 * <collaborativeclouds@gmail.com>
 */
public class QRCodeConfiguration {
    
    public static int SIZE=125;
    public static String FILETYPE="png";
    public static BarcodeFormat FORMAT=BarcodeFormat.QR_CODE;
}
